
typedef struct disc {
   char id[10];
   char title[100];
   char program[700];
   char schedule[50];
   char commentary[200];
} discipline;


